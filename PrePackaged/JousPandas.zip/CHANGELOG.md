# 1.0.0
lets gooooooooo

# 1.0.1
make it more acurate and cartoony like other species.

# 1.0.2
Fix Import