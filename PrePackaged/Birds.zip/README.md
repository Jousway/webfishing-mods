# Webfishing Birds

<p align="center">
	<img src="https://raw.githubusercontent.com/Jousway/webfishing-mods/refs/heads/main/Images/Birds.png"/>
</p>

Bird Fishing


## Contact
Jousway/Zettbou on modding webfishing discord.