# 1.0.0
lets BORDER.

# 1.0.1
Add Deactivate and Outline Strength options.

# 1.1.0
Add Knit mode.