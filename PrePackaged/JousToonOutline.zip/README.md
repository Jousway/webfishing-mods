# Webfishing Jous-ToonOutline

<p align="center">
	<img src="https://raw.githubusercontent.com/Jousway/webfishing-mods/refs/heads/main/Images/ToonOutline.png"/>
</p>

Outline Fishing


## Contact
Jousway/Zettbou on modding webfishing discord.