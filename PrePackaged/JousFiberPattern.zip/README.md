# Webfishing Jous-FiberPattern

<p align="center">
	<img src="https://raw.githubusercontent.com/Jousway/webfishing-mods/refs/heads/main/Images/FiberPattern.png"/>
</p>

Sackboy Fishing


## Contact
Jousway/Zettbou on modding webfishing discord.