# 1.0.0
lets goooooooooats

# 1.0.1
Fix Readme.

# 1.0.2
Fix cosmetics being connected to wrong bone.