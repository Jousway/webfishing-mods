# Webfishing Goats

<p align="center">
	<img src="https://raw.githubusercontent.com/Jousway/webfishing-mods/refs/heads/main/Images/Goats.png"/>
</p>

Goat Fishing


## Contact
Jousway/Zettbou on modding webfishing discord.