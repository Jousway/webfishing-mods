# Webfishing Jous-WF_RatsRespect

<p align="center">
	<img src="https://raw.githubusercontent.com/Jousway/webfishing-mods/refs/heads/main/Images/WF_RatsRespect.png"/>
</p>

Smol Fishing

Inspired by the de_rats2 from Chris Spain for CS 1.6.


## Contact
Jousway/Zettbou on modding webfishing discord.